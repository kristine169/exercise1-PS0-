# ITSEPC-Problem-sets

TODO:

- [x ] Start with drawSquare. Make it draw a correct square. Run npm start to see the output in output.html.

- [ x] Implement chordLength. Run npm test and make sure the chordLength tests pass (turn green).

- [x ] Implement drawApproximateCircle using chordLength. Run npm start and visually check output.html.

- [ x] Implement distance. Run npm test and make sure the distance tests pass.

- [ x] Implement findPath. For Problem Set 0, focus on the logic of finding a path. The current test is very basic. You might want to add more tests or think about how you would conceptually verify the path.

- [ x] Implement drawPersonalArt. Be creative! Run npm start and visually check output.html. Make sure it's at least 20 lines of non-repetitive code.
